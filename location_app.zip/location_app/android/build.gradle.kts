import 'package:flutter/material.dart';
import 'package:location_app/models/app_location.dart';
import 'package:location_app/screens/add_edit_location_screen.dart';
import 'package:location_app/screens/location_map_screen.dart';
import 'package:location_app/services/database_helper.dart';

class LocationListScreen extends StatefulWidget {
    const LocationListScreen({super.key});

    @override
    State<LocationListScreen> createState() => _LocationListScreenState();
}

class _LocationListScreenState extends State<LocationListScreen> {
    List<AppLocation> _locations = [];

    @override
    void initState() {
        super.initState();
        _loadLocations();
    }

    Future<void> _loadLocations() async {
        final locations = await DatabaseHelper.instance.fetchLocations();
        setState(() {
            _locations = locations;
        });
    }

    Future<void> _deleteLocation(String id) async {
        await DatabaseHelper.instance.deleteLocation(id);
        _loadLocations();
    }

    void _navigateToAddEdit({AppLocation? location}) async {
        await Navigator.push(
                context,
        MaterialPageRoute(
            builder: (_) => AddEditLocationScreen(
        isEdit: location != null,
        location: location,
        ),
        ),
        );
        _loadLocations();
    }

    void _openMap(AppLocation location) {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => LocationMapScreen(location: location),
        ),
        );
    }

    @override
    Widget build(BuildContext context) {
        return Scaffold(
            appBar: AppBar(
                    title: const Text('Your Locations'),
        ),
        body: _locations.isEmpty
        ? const Center(child: Text('No locations added.'))
        : ListView.builder(
        itemCount: _locations.length,
        itemBuilder: (context, index) {
        final location = _locations[index];
        return ListTile(
            title: Text(location.name ?? 'No Name'),
        subtitle: Text(
        'Lat: ${location.latitude}, Lng: ${location.longitude}'),
        onTap: () => _openMap(location),
        trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
        IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () => _navigateToAddEdit(location: location),
        ),
        IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () => _deleteLocation(location.id!),
        ),
        ],
        ),
        );
    },
        ),
        floatingActionButton: FloatingActionButton(
        onPressed: () => _navigateToAddEdit(),
        child: const Icon(Icons.add),
        ),
        );
    }
}
