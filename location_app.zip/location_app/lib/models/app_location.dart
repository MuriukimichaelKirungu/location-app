class AppLocation {
  String id;
  String? name;
  double latitude;
  double longitude;

  AppLocation({
    required this.id,
    this.name,
    required this.latitude,
    required this.longitude,
  });

  // fromMap method - convert Map to AppLocation object
  factory AppLocation.fromMap(Map<String, dynamic> map) {
    return AppLocation(
      id: map['id']?.toString() ?? '',
      name: map['name'],
      latitude: map['latitude'],
      longitude: map['longitude'],
    );
  }


  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'latitude': latitude,
      'longitude': longitude,
    };
  }
}
