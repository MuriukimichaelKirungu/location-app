class Location {
  final String id;
  final double? latitude;
  final double? longitude;
  final String? name;

  Location({
    required this.id,
    this.latitude,
    this.longitude,
    this.name,
  });
}
