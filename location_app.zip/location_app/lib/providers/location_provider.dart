import 'package:flutter/material.dart';
import '../models/app_location.dart';
import '../services/database_helper.dart';

class LocationProvider with ChangeNotifier {
  List<AppLocation> _locations = [];

  List<AppLocation> get locations => _locations;

  Future<void> loadLocations() async {
    _locations = await DatabaseHelper.instance.fetchLocations();
    notifyListeners();
  }

  Future<void> addLocation(AppLocation location) async {
    await DatabaseHelper.instance.insertLocation(location);
    await loadLocations();
  }

  Future<void> updateLocation(AppLocation location) async {
    await DatabaseHelper.instance.updateLocation(location);
    await loadLocations();
  }

  Future<void> deleteLocation(String id) async {
    await DatabaseHelper.instance.deleteLocation(id);
    await loadLocations();
  }

  AppLocation? getLocationById(String id) {
    try {
      return _locations.firstWhere((loc) => loc.id == id);
    } catch (e) {
      return null;
    }
  }
}
