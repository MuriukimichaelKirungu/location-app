import 'package:flutter/material.dart';
import 'package:location_app/models/app_location.dart';
import 'package:location_app/services/database_helper.dart';
import 'package:uuid/uuid.dart';

class AddEditLocationScreen extends StatefulWidget {
  final bool isEdit;
  final AppLocation? initialLocation;

  const AddEditLocationScreen({
    Key? key,
    required this.isEdit,
    this.initialLocation,
  }) : super(key: key);

  @override
  _AddEditLocationScreenState createState() => _AddEditLocationScreenState();
}

class _AddEditLocationScreenState extends State<AddEditLocationScreen> {
  late TextEditingController _nameController;
  late double _latitude;
  late double _longitude;
  late String _id;

  @override
  void initState() {
    super.initState();
    if (widget.isEdit && widget.initialLocation != null) {
      _nameController = TextEditingController(text: widget.initialLocation!.name);
      _latitude = widget.initialLocation!.latitude;
      _longitude = widget.initialLocation!.longitude;
      _id = widget.initialLocation!.id;  // Set ID for editing
    } else {
      _nameController = TextEditingController();
      _latitude = 0.0;
      _longitude = 0.0;
      _id = Uuid().v4();  // Generate new ID if adding a location
    }
  }

  void _saveLocation() async {
    final location = AppLocation(
      id: _id,
      name: _nameController.text,
      latitude: _latitude,
      longitude: _longitude,
    );

    if (widget.isEdit) {
      await DatabaseHelper.instance.updateLocation(location);
    } else {
      await DatabaseHelper.instance.insertLocation(location);
    }
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: widget.isEdit ? const Text('Edit Location') : const Text('Add Location'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Location Name'),
            ),
            TextField(
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Latitude'),
              onChanged: (value) => setState(() {
                _latitude = double.tryParse(value) ?? 0.0;
              }),
            ),
            TextField(
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Longitude'),
              onChanged: (value) => setState(() {
                _longitude = double.tryParse(value) ?? 0.0;
              }),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _saveLocation,
              child: Text(widget.isEdit ? 'Save Changes' : 'Add Location'),
            ),
          ],
        ),
      ),
    );
  }
}
