import 'package:flutter/material.dart';
import 'package:location_app/models/app_location.dart';
import 'package:location_app/screens/add_edit_location_screen.dart';
import 'package:location_app/services/database_helper.dart';

class LocationListScreen extends StatefulWidget {
  const LocationListScreen({Key? key}) : super(key: key);

  @override
  _LocationListScreenState createState() => _LocationListScreenState();
}

class _LocationListScreenState extends State<LocationListScreen> {
  List<AppLocation> _locations = [];

  @override
  void initState() {
    super.initState();
    _loadLocations();
  }

  Future<void> _loadLocations() async {
    final locations = await DatabaseHelper.instance.fetchLocations();
    setState(() {
      _locations = locations;
    });
  }


  void _navigateToAddLocation() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => AddEditLocationScreen(isEdit: false),
      ),
    );
    _loadLocations();
  }

  void _navigateToEditLocation(AppLocation location) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => AddEditLocationScreen(
          isEdit: true,
          initialLocation: location,
        ),
      ),
    );
    _loadLocations();
  }

  void _deleteLocation(String id) async {
    await DatabaseHelper.instance.deleteLocation(id);
    _loadLocations();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Saved Locations'),
      ),
      body: ListView.builder(
        itemCount: _locations.length,
        itemBuilder: (context, index) {
          final location = _locations[index];
          return ListTile(
            title: Text(location.name ?? 'No Name'),
            subtitle: Text(
              'Lat: ${location.latitude}, Lng: ${location.longitude}',
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => _navigateToEditLocation(location),
                ),
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () => _deleteLocation(location.id),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddLocation,
        child: const Icon(Icons.add),
      ),
    );
  }
}
