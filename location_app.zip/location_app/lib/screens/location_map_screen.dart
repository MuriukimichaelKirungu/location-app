import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location_app/models/app_location.dart';

class LocationMapScreen extends StatelessWidget {
  final AppLocation location;

  const LocationMapScreen({Key? key, required this.location}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(location.name ?? 'Location'),
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: LatLng(
            location.latitude ?? 0.0,  // Ensure non-nullable double value
            location.longitude ?? 0.0, // Ensure non-nullable double value
          ),
          zoom: 12.0,
        ),
        markers: {
          Marker(
            markerId: MarkerId(location.id),
            position: LatLng(
              location.latitude ?? 0.0,
              location.longitude ?? 0.0,
            ),
            infoWindow: InfoWindow(title: location.name ?? 'Unnamed Location'),
          ),
        },
      ),
    );
  }
}
