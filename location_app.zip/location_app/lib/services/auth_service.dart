import 'dart:async';

class AuthService {
  Future<String?> login(String email, String password) async {
    // Simulate network delay
    await Future.delayed(const Duration(seconds: 2));

    // Fake check (in real case, you’d hit an API)
    if (email == "test@example.com" && password == "password") {
      return "mock_token_12345"; // mock JWT or session token
    } else {
      return null;
    }
  }

  Future<bool> register(String name, String email, String password) async {
    await Future.delayed(const Duration(seconds: 2));

    // Simulate successful registration
    return true;
  }
}
